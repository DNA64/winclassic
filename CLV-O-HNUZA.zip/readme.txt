Please download and use the appropriate dosbox.conf
file for your system, region and configuration (USB or NAND),
available here: https://github.com/dna64/winclassic